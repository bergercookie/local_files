% Copyright 2009 The MathWorks(TM), Inc.
set(gcf,'Position',[765   405   449   336]);
box on
text(200,25,'Testing Time (normal): 93.2 sec','FontSize',12,'FontWeight','Bold'); 
text(200,15,'Testing Time (two cores): 53.4 sec','FontSize',12,'FontWeight','Bold'); 
axis([0 1200 0 100])
