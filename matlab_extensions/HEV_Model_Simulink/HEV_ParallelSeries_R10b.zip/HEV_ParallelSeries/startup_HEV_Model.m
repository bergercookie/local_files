% Copyright 2010 The MathWorks, Inc.

HEV_Model_HomeDir = pwd;
addpath(pwd);
addpath([pwd '/Libraries/Electrical']);
addpath([pwd '/Libraries/Battery']);
addpath([pwd '/Libraries/Vehicle']);
addpath([pwd '/Images']);
addpath([pwd '/Scripts_Data']);
addpath([pwd '/Reports']);

HEV_Model_PARAM

HEV_SeriesParallel




